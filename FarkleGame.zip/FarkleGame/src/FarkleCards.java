import java.awt.Desktop;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;
import javafx.scene.effect.*;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.geometry.Insets;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;
import javafx.scene.effect.*;
import javafx.scene.control.Alert.AlertType;
import javax.swing.JOptionPane;

import javafx.geometry.Pos;
import javafx.scene.shape.*;

public class FarkleCards extends Application {
	public static void main(String[] args) {
		System.setProperty("javafx.macosx.embedded", "true");  
        Toolkit.getDefaultToolkit();
		Application.launch(args);
	}

	private int count, countB, i, j, C3, C4, ones, twos, threes, fours, fives, sixes, totalC, totalP, TurnScoreC,
			TurnScoreP, currentScoreC, currentScoreP, TurnScore,TurnScoreFC,TurnScoreFP;
	private String winner;
	private int x = 3;
	private int Pturn = 0, Cturn = 1;
	private int NoOfFP = 0, NoOfFC = 0;
	private boolean newCard = false;
	private Button playerB;
	private Button computerB;
	private Button countCombo, countFarkle;
	private PathTransition moveToComputer, moveToPlayers2;
	private Image[] pic;
	private ImageView[] picFrame;
	private ImageView[] fixedpicFrame;
	private ImageView picV;
	private HBox Computer;
	private HBox player1Hand;
	private StackPane farkleComputer;
	private StackPane farklePlayer;
	private Text textC, textP;
	private Label CTSP1Value,CTSP2Value;

	ArrayList<Integer> cardIndexC;
	ArrayList<Integer> cardIndexP;

	boolean condition = true;
	// private Text error1, error2, error3;

	private int[] indexForCard;
	TextField P1Name;
	TextField P2Name;

	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		// Create deckpane
		StackPane deckpane = new StackPane();
		deckpane.setPrefWidth(50);
		deckpane.setPrefHeight(50);
		deckpane.setLayoutX(300);
		deckpane.setLayoutY(300);
		Pane PosPane = new Pane();

		// Player Farkle Pane
		StackPane farklePlayer = new StackPane();
		VBox VPlay = new VBox();
		VPlay.setAlignment(Pos.CENTER);
		Text FP = new Text("Farkle Cards of Player 2");
		Text NoOfF_forP = new Text(Integer.toString(NoOfFP));
		NoOfF_forP.setFont(Font.font("Arial", FontWeight.BOLD, 20));
		NoOfF_forP.setFill(Color.WHITE);
		FP.setFill(Color.WHITE);
		FP.setFont(Font.font("Arial", FontWeight.BOLD, 14));
		VPlay.setLayoutX(900);
		VPlay.setLayoutY(500);

		// Computer Farkle Pane
		StackPane farkleComputer = new StackPane();
		VBox VComp = new VBox();
		VComp.setAlignment(Pos.CENTER);
		Text FC = new Text("Farkle Cards of Player 1");
		Text NoOfF_forC = new Text(Integer.toString(NoOfFC));
		NoOfF_forC.setFont(Font.font("Arial", FontWeight.BOLD, 20));
		NoOfF_forC.setFill(Color.WHITE);
		FC.setFill(Color.WHITE);
		FC.setFont(Font.font("Arial", FontWeight.BOLD, 14));
		VComp.setLayoutX(900);
		VComp.setLayoutY(30);

		// create the main pane
		Pane mainPane = new Pane();
		mainPane.setPrefHeight(900);
		mainPane.setPrefWidth(1060);
		mainPane.setBackground(new Background(new BackgroundImage(new Image("back.png"), BackgroundRepeat.REPEAT,
				BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT)));
	
		GridPane player1Hand = new GridPane();
		player1Hand.setLayoutX(60);
		player1Hand.setLayoutY(500);

		// computers pane
		GridPane Computer = new GridPane();
		Computer.setLayoutX(60);
		Computer.setLayoutY(30);

		HBox middlePane = new HBox();
		middlePane.setSpacing(10);
		middlePane.getChildren().addAll(deckpane, PosPane);
		middlePane.layoutXProperty().bind(mainPane.widthProperty().divide(2).subtract(30));
		middlePane.layoutYProperty().bind(mainPane.heightProperty().divide(2).subtract(45));

		// DashScore of the GAME
		Circle CP1 = new Circle(20);
		CP1.setFill(Color.WHITE);
		Circle CP2 = new Circle(20);
		CP2.setFill(Color.WHITE);
		ImageView scorePoints = new ImageView(new Image("score1.png"));
		scorePoints.setFitHeight(110);
		scorePoints.setFitWidth(300);

		Text Ply1Name = new Text("Player 1 Name");

		Ply1Name.setFont(Font.font("Arial", FontWeight.NORMAL, 14));

		Text Ply2Name = new Text("Player 2 Name");
		Ply2Name.setFill(Color.WHITE);

		Ply2Name.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
		GridPane Player1Frame = new GridPane();
		Player1Frame.setPadding(new Insets(10, 10, 10, 10));
		GridPane Player2Frame = new GridPane();
		Player2Frame.setPadding(new Insets(10, 10, 10, 10));
		Player1Frame.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
		Player1Frame.setPrefWidth(150);
		Player1Frame.setPrefHeight(600);
		Player1Frame.add(CP1, 0, 0);
		Player1Frame.add(Ply1Name, 0, 1);

		Player2Frame.setBackground(
				new Background(new BackgroundFill(Color.web("#583f9a"), CornerRadii.EMPTY, Insets.EMPTY)));
		Player2Frame.setPrefWidth(150);
		Player2Frame.setPrefHeight(600);
		Player2Frame.add(CP2, 0, 0);
		Player2Frame.add(Ply2Name, 0, 1);
		
		// show current total score
		Text cTSP1 = new Text("Total Score=");
		Text cTSP2 = new Text("Total Score=");
		Player1Frame.add(cTSP1, 0, 2);
		Player2Frame.add(cTSP2, 0, 2);

		HBox ScoreBoard = new HBox();
		Text Slabel = new Text("ScoreBoard");
		Text instru = new Text("the Yellow Circle Represents Player Turn");
		Slabel.setFont(Font.font("Arial", FontWeight.NORMAL, 17));
		Slabel.setFill(Color.DARKGREEN);
		ScoreBoard.getChildren().addAll(Player1Frame, Player2Frame);
		VBox leftSide = new VBox();
		leftSide.setSpacing(10);
		leftSide.setAlignment(Pos.CENTER);
		leftSide.getChildren().addAll(scorePoints, Slabel, instru, ScoreBoard);
		HBox FRAME = new HBox();
		FRAME.getChildren().addAll(mainPane, leftSide);

		// Player Button
		playerB = new Button("Put in Player 2 Cards");
		playerB.setPrefWidth(180);
		playerB.layoutXProperty().bind(player1Hand.layoutXProperty());
		playerB.layoutYProperty().bind(player1Hand.layoutYProperty().add(player1Hand.layoutYProperty().divide(3.6)));
		// computer Button
		computerB = new Button("Put in Player 1 Cards");
		computerB.setPrefWidth(180);
		computerB.layoutXProperty().bind(Computer.layoutXProperty());
		computerB.layoutYProperty().bind(Computer.layoutYProperty().add(Computer.layoutYProperty().multiply(4.5)));

		// button for adding combo score
		countCombo = new Button();
		Text SCLabel = new Text("Count Combinations for score");
		SCLabel.setFill(Color.WHITE);
		SCLabel.layoutYProperty().bind(countCombo.layoutYProperty().add(60));
		SCLabel.layoutXProperty().bind(countCombo.layoutXProperty());
		ImageView Sicon = new ImageView(new Image("scoreIcon.png"));
		countCombo.setGraphic(Sicon);
		countCombo.layoutXProperty().bind(player1Hand.layoutXProperty());
		countCombo.setTextFill(Color.PURPLE);

		// button for adding farkle combo score
		countFarkle = new Button();
		Text FBLabel = new Text("Count Farkles");
		FBLabel.setFill(Color.WHITE);
		FBLabel.layoutYProperty().bind(countFarkle.layoutYProperty().add(60));
		FBLabel.layoutXProperty().bind(countFarkle.layoutXProperty());
		ImageView Ficon = new ImageView(new Image("Ficon.png"));
		countFarkle.setGraphic(Ficon);
		countFarkle.layoutXProperty().bind(player1Hand.layoutXProperty());
		countCombo.layoutYProperty().bind(mainPane.heightProperty().divide(2));
		countFarkle.layoutYProperty().bind(mainPane.heightProperty().divide(3));

		// Create a list of Integers
		ArrayList<Integer> cards = getCards();
		// Create a list of imageViews for computer/player to save the indices for
		// scoring logic
		ArrayList<Integer> cardIndexC = new ArrayList<>();
		ArrayList<Integer> cardIndexP = new ArrayList<>();

		fixedpicFrame = new ImageView[106];

		// fixed ID of the cards in the array
		for (j = 0; j < 106; j++) {

			fixedpicFrame[j] = new ImageView(new Image(j + ".png"));
			String ID_CARD = Integer.toString(j);
			fixedpicFrame[j].setId(ID_CARD);
			System.out.println(fixedpicFrame[j].getId());
		}

		// Create the arrays for the images and their frames
		pic = new Image[106];
		picFrame = new ImageView[106];
		// Place 106 nodes in the pane in the middle

		for (count = 0; count < 106; count++) {
			pic[count] = new Image(cards.get(count) + ".png");
			picFrame[count] = new ImageView(pic[count]);
			picFrame[count].setFitHeight(130);
			picFrame[count].setFitWidth(90);
			picFrame[count].setId(fixedpicFrame[cards.get(count)].getId());
			System.out.println(picFrame[count].getId());
			deckpane.getChildren().add(picFrame[count]);
		}

		ImageView CoverOfDeck = new ImageView(new Image("106.png"));
		CoverOfDeck.setFitHeight(130);
		CoverOfDeck.setFitWidth(90);
		deckpane.getChildren().add(CoverOfDeck);

		// add initial cards for both players and make sure it's not a Farkle Card
		Random R = new Random();
		int R1 = R.nextInt(106);
		int R2 = R.nextInt(106);
		int C1 = Integer.parseInt(picFrame[R1].getId());
		int C2 = Integer.parseInt(picFrame[R2].getId());

		C3 = Integer.parseInt(fixedpicFrame[84].getId());
		C4 = Integer.parseInt(fixedpicFrame[105].getId());

		while (condition == true) {

			while ((C1 >= C3 && C1 <= C4) || (C2 >= C3 && C2 <= C4)) {
				R1 = R.nextInt(106);
				R2 = R.nextInt(106);

				C1 = Integer.parseInt(picFrame[R1].getId());
				C2 = Integer.parseInt(picFrame[R2].getId());
			}

			condition = false;
		}

		player1Hand.addRow(0, picFrame[R1]);
		cardIndexP.add(Integer.parseInt(picFrame[R1].getId()));
		getCards().remove(R1);
		Computer.addRow(0, picFrame[R2]);
		cardIndexC.add(Integer.parseInt(picFrame[R2].getId()));
		getCards().remove(R2);

		int CurrentPlayer;
		CurrentPlayer = (int) Math.random() * 2;

		if (CurrentPlayer == 0) {
			CurrentPlayer = Pturn;
			CP1.setFill(Color.YELLOW);
		}

		else {
			CP2.setFill(Color.YELLOW);
			CurrentPlayer = Cturn;
		}

		// move the cards depending on the keys pressed and discard that card from
		// 'cards' ArrayList
		deckpane.setOnMousePressed(e -> {
			if(cards.isEmpty()==false) {
			for (i = x; i <= x; i++) {
				PosPane.getChildren().addAll(picFrame[i]);
				picV = picFrame[i];

			}

			if (Integer.parseInt(picV.getId()) >= C3 && Integer.parseInt(picV.getId()) <= C4) {

				if (CP2.getFill() == Color.YELLOW) {
					computerB.setDisable(true);
					countCombo.setDisable(true);

				}

				else if (CP1.getFill() == Color.YELLOW) {
					playerB.setDisable(true);
					countCombo.setDisable(true);

				}

			} else {
				playerB.setDisable(false);
				computerB.setDisable(false);

			}
			playerB.setOnAction(a -> {
				computerB.setDisable(false);
				if (PosPane.getChildren().contains(picV)) {
					// to double check it goes in this if condition
					System.out.println("Yes Card");
					// playerB.setDisable(false);
					if (Integer.parseInt(picV.getId()) >= C3 & Integer.parseInt(picV.getId()) <= C4) {
						farklePlayer.getChildren().addAll(picV);
						NoOfFP++;
						NoOfF_forP.setText(Integer.toString(NoOfFP));
						CP2.setFill(Color.WHITE);
						CP1.setFill(Color.YELLOW);
						countCombo.setDisable(false);
						Text F2 = new Text("FARKLE");
						F2.setFill(Color.YELLOWGREEN);
						Player2Frame.addColumn(0, F2);
					} else {

						cardIndexP.add(Integer.parseInt(picV.getId()));
						player1Hand.addRow(0, picV);
					}

				} else {
					System.out.println("No Cards");
					playerB.setDisable(true);
					JOptionPane.showMessageDialog(null, "There is No Card, Please Click on the Deck");

				}
				getCards().remove(i);
				x++;
			});
			computerB.setOnAction(a -> {
				if (PosPane.getChildren().contains(picV)) {
					System.out.println("Yes Card");
					playerB.setDisable(false);

					if (Integer.parseInt(picV.getId()) >= C3 & Integer.parseInt(picV.getId()) <= C4) {
						farkleComputer.getChildren().addAll(picV);
						NoOfFC++;
						NoOfF_forC.setText(Integer.toString(NoOfFC));
						CP1.setFill(Color.WHITE);
						CP2.setFill(Color.YELLOW);
						countCombo.setDisable(false);
						Text F1 = new Text("FARKLE");
						F1.setFill(Color.YELLOWGREEN);
						Player1Frame.addColumn(0, F1);
					} else {

						cardIndexC.add(Integer.parseInt(picV.getId()));
						Computer.addRow(0, picV);
					}
				}

				else {
					System.out.println("No Cards");
					computerB.setDisable(true);

					JOptionPane.showMessageDialog(null, "There is No Card, Plz Click on the Deck");

				}
				getCards().remove(i);
				x++;
			});
			}
			else if(cards.isEmpty()==true) {
				if(currentScoreC> currentScoreP) {
					Alert alert = new Alert(AlertType.INFORMATION, "Computer has won! Click OK to exit game");
					alert.initOwner(primaryStage);
					Optional<ButtonType> result = alert.showAndWait();
					if (result.isPresent() && result.get() == ButtonType.OK) {
						System.exit(0);
					}
				} else if( currentScoreC<currentScoreP) {
					Alert alert = new Alert(AlertType.INFORMATION, "Player has won! Click OK to exit game");
					alert.initOwner(primaryStage);
					Optional<ButtonType> result = alert.showAndWait();
					if (result.isPresent() && result.get() == ButtonType.OK) {
						System.exit(0);
					}
				}
			}
		});

		// When the user presses on count combinations button to score what they have in
		// their turn
		countCombo.setOnAction(e -> {
			TurnScore = getScore(cardIndexC, Computer) + getScore(cardIndexP, player1Hand);
	
			Text text = new Text(Integer.toString(TurnScore));

			if (CP1.getFill() == Color.YELLOW) {
				Player1Frame.getChildren().remove(CTSP1Value);
				Player1Frame.addColumn(0, text);
				currentScoreC = TurnScore + currentScoreC;
				CTSP1Value = new Label();				
				CTSP1Value.setText(Integer.toString(currentScoreC));
				Player1Frame.add(CTSP1Value, 1, 2);
			}

			else {
				Player2Frame.getChildren().remove(CTSP2Value);
				Player2Frame.addColumn(0, text);
				currentScoreP = TurnScore + currentScoreP;
				CTSP2Value = new Label();				
				CTSP2Value.setText(Integer.toString(currentScoreP));
				Player2Frame.add(CTSP2Value, 1, 2);

			}
			if (checkWinner(currentScoreC, currentScoreP) == "Player1") {
				Alert alert = new Alert(AlertType.INFORMATION, "Player 1 has won! Click OK to exit game");
				alert.initOwner(primaryStage);
				Optional<ButtonType> result = alert.showAndWait();
				if (result.isPresent() && result.get() == ButtonType.OK) {
					System.exit(0);
				}
			} else if (checkWinner(currentScoreC, currentScoreP) == "Player2") {
				Alert alert = new Alert(AlertType.INFORMATION, "Player 2 has won! Click OK to exit game");
				alert.initOwner(primaryStage);
				Optional<ButtonType> result = alert.showAndWait();
				if (result.isPresent() && result.get() == ButtonType.OK) {
					System.exit(0);
				}
			}
		});
		// When the user presses on count farkles button to score what they have in
		// their turn
		countFarkle.setOnAction(e -> {
			if (CP1.getFill() == Color.YELLOW) {
				Player1Frame.getChildren().remove(CTSP1Value);
				TurnScoreC = getScoreFarkle(NoOfFC);
				textC = new Text(Integer.toString(TurnScoreC));
				Player1Frame.addColumn(0, textC);
				farkleComputer.getChildren().clear();
				NoOfF_forC.setText("0");
				currentScoreC = TurnScoreC + currentScoreC;
				CTSP1Value = new Label();				
				CTSP1Value.setText(Integer.toString(currentScoreC));
				Player1Frame.add(CTSP1Value, 1, 2);
				
			} else if (CP2.getFill() == Color.YELLOW) {
				Player2Frame.getChildren().remove(CTSP2Value);
				TurnScoreP = getScoreFarkle(NoOfFP);
				textP = new Text(Integer.toString(TurnScoreP));
				Player2Frame.addColumn(0, textP);
				farklePlayer.getChildren().clear();
				NoOfF_forP.setText("0");
				currentScoreP = TurnScoreP + currentScoreP;
				CTSP2Value = new Label();				
				CTSP2Value.setText(Integer.toString(currentScoreP));
				Player2Frame.add(CTSP2Value, 1, 2);
			}
			NoOfFC = 0;
			NoOfFP = 0;
			if (checkWinner(currentScoreC, currentScoreP) == "Player1") {
				Alert alert = new Alert(AlertType.INFORMATION, "Player 1 has won! Click OK to exit game");
				alert.initOwner(primaryStage);
				Optional<ButtonType> result = alert.showAndWait();
				if (result.isPresent() && result.get() == ButtonType.OK) {
					System.exit(0);
				}
			} else if (checkWinner(currentScoreC, currentScoreP) == "Player2") {
				Alert alert = new Alert(AlertType.INFORMATION, "Player 2 has won! Click OK to exit game");
				alert.initOwner(primaryStage);
				Optional<ButtonType> result = alert.showAndWait();
				if (result.isPresent() && result.get() == ButtonType.OK) {
					System.exit(0);
				}
			}
		});
		
		//to open the pdf rule sheet... code needs alteration if the OS is windows for path directory string
        scorePoints.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent arg0) {
                // TODO Auto-generated method stub
                File pdfFile = new File("/Users/ruaaobeid/eclipse-workspace/chapter14/bin");
                if (pdfFile.exists()){
                 if (Desktop.isDesktopSupported()){
                  try{
                   Desktop.getDesktop().open(pdfFile);
                  }
                  catch (IOException e){ 
                   e.printStackTrace();
                  }
                 }
                 else{
                   System.out.println("Awt Desktop is not supported!");
                  }
                }
                else{
                 System.out.println("File does not exist!");
                }
              }
       });

		VPlay.getChildren().addAll(FP, farklePlayer, NoOfF_forP);
		VComp.getChildren().addAll(FC, farkleComputer, NoOfF_forC);

		mainPane.getChildren().addAll(middlePane, Computer, VComp, player1Hand, VPlay, countCombo, playerB, computerB,
				countFarkle, FBLabel, SCLabel);

		// Create Welcome Scene
		Button Switch = new Button("GO FARKLE GAME");
		Switch.setTextFill(Color.web("#583f9a"));
		DropShadow shadow = new DropShadow();
		// Adding the shadow when the mouse cursor is on
		Switch.addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				Switch.setEffect(shadow);
			}
		});
		// Removing the shadow when the mouse cursor is off
		Switch.addEventHandler(MouseEvent.MOUSE_EXITED, new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				Switch.setEffect(null);
			}
		});

		TextField P1Name = new TextField();
		TextField P2Name = new TextField();

		Text P1N = new Text("Enter Player 1 Name");
		Text P2N = new Text("Enter Player 2 Name");
		P1N.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
		P2N.setFont(Font.font("Arial", FontWeight.NORMAL, 16));
		P1N.setFill(Color.WHITE);
		P2N.setFill(Color.WHITE);

		ImageView WelcomeImage = new ImageView(new Image("coverScene2.png"));

		VBox NodeScene2 = new VBox(20);
		NodeScene2.setAlignment(Pos.CENTER);
		NodeScene2.setMaxHeight(300);
		NodeScene2.setMaxWidth(300);
		NodeScene2.setPrefWidth(100);

		NodeScene2.getChildren().addAll(P1N, P1Name, P2N, P2Name, Switch);
		StackPane W = new StackPane();
		W.getChildren().addAll(WelcomeImage, NodeScene2);

		Scene Welcomescene = new Scene(W, 1500, 800);
		// Create a scene and place it in the stage
		Scene scene = new Scene(FRAME, 1500, 800);
		Switch.setOnAction(e -> {
			primaryStage.setScene(scene);
			Ply1Name.setText(P1Name.getText());
			Ply2Name.setText(P2Name.getText());
		});

		primaryStage.setScene(Welcomescene); // Place the scene in the stage
		primaryStage.show(); // Display the stage

	}

	// Return a shuffled list of Integers 1-106
	private ArrayList<Integer> getCards() {
		ArrayList<Integer> c = new ArrayList<>();
		for (int i = 0; i < 106; i++)
			c.add(i);
		java.util.Collections.shuffle(c);
		return c;
	}

	// calculating score of normal cards
	private int getScore(ArrayList<Integer> Array, GridPane Pane) {
		ones = 0;
		twos = 0;
		threes = 0;
		fours = 0;
		fives = 0;
		sixes = 0;
		totalC = 0;
		for (int i = 0; i <= 13; i++) {
			if (Array.contains(i)) {
				ones++;
				
			}
		}
		for (int i = 14; i <= 27; i++) {
			if (Array.contains(i)) {
				twos++;
				

			}
		}
		for (int i = 28; i <= 41; i++) {
			if (Array.contains(i)) {
				threes++;
				

			}
		}
		for (int i = 42; i <= 55; i++) {
			if (Array.contains(i)) {
				fours++;
			

			}
		}
		for (int i = 56; i <= 69; i++) {
			if (Array.contains(i)) {
				fives++;
				

			}
		}
		for (int i = 70; i <= 83; i++) {
			if (Array.contains(i)) {
				sixes++;
				

			}
		}
		System.out.printf("i have %d 1's%n", ones);
		System.out.printf("i have %d 2's%n", twos);
		System.out.printf("i have %d 3's%n", threes);
		System.out.printf("i have %d 4's%n", fours);
		System.out.printf("i have %d 5's%n", fives);
		System.out.printf("i have %d 6's%n", sixes);
		System.out.println("SIZE" + Array.size());

		if (sixes == 3 || sixes == 4 || sixes == 5 || sixes == 6) {

			int INC = 0;
			if (sixes == 3) {
				INC = 3;
				totalC += 600;
			} else if (sixes == 4) {
				INC = 4;
				totalC += 1000;
			} else if (sixes == 5) {
				INC = 5;
				totalC += 2000;
			} else if (sixes == 6) {
				INC = 6;
				totalC += 3000;
			}
			System.out.println("the value of INc for 6 is " + INC);
			REMOVE(0, INC, 70, 83, Array, Pane);
			System.out.println("array after removal is working");
			for (int i = 0; i < Array.size(); i++) {
				System.out.println(Array.get(i));
			}
		}

		if (fives == 3 || fives == 4 || fives == 5 || fives == 6) {

			int INC = 0;
			if (fives == 3) {
				INC = 3;
				totalC += 500;
			} else if (fives == 4) {
				INC = 4;
				totalC += 1000;
			} else if (fives == 5) {
				INC = 5;
				totalC += 2000;
			} else if (fives == 6) {
				INC = 6;
				totalC += 3000;
			}

			System.out.println("the value of INc for 5 is " + INC);
			REMOVE(0, INC, 56, 69, Array, Pane);
			System.out.println("array after removal is working");
			for (int i = 0; i < Array.size(); i++) {
				System.out.println(Array.get(i));
			}
		}
		if (fours == 3 || fours == 4 || fours == 5 || fours == 6) {

			int INC = 0;
			if (fours == 3) {
				INC = 3;
				totalC += 400;
			} else if (fours == 4) {
				INC = 4;
				totalC += 1000;
			} else if (fours == 5) {
				INC = 5;
				totalC += 2000;
			} else if (fours == 6) {
				INC = 6;
				totalC += 3000;
			}

			System.out.println("the value of INc for 4 is " + INC);
			int c = 0;
			REMOVE(0, INC, 42, 55, Array, Pane);
			System.out.println("array after removal is working");

			for (int i = 0; i < Array.size(); i++) {
				System.out.println(Array.get(i));
			}

		}

		if (threes == 3 || threes == 4 || threes == 5 || threes == 6) {
			int INC = 0;
			if (threes == 3) {
				INC = 3;
				totalC += 300;
			} else if (threes == 4) {
				INC = 4;
				totalC += 1000;
			} else if (threes == 5) {
				INC = 5;
				totalC += 2000;
			} else if (threes == 6) {
				INC = 6;
				totalC += 3000;
			}

			System.out.println("the value of INc for 3 is " + INC);
			int c = 0;
			REMOVE(0, INC, 28, 41, Array, Pane);
			System.out.println("array after removal is working");
			for (int i = 0; i < Array.size(); i++) {
				System.out.println(Array.get(i));
			}

		}

		if (twos == 3 || twos == 4 || twos == 5 || twos == 6) {
			int INC = 0;
			if (twos == 3) {
				INC = 3;
				totalC += 200;
			} else if (twos == 4) {
				INC = 4;
				totalC += 1000;
			} else if (twos == 5) {
				INC = 5;
				totalC += 2000;
			} else if (twos == 6) {
				INC = 6;
				totalC += 3000;
			}

			System.out.println("the value of INc for 2 is " + INC);
			REMOVE(0, INC, 14, 27, Array, Pane);
			System.out.println("array after removal is working");
			for (int i = 0; i < Array.size(); i++) {
				System.out.println(Array.get(i));
			}

		}

		if (ones == 3 || ones == 4 || ones == 5 || ones == 6) {
			int INC = 0;

			if (ones == 3) {
				INC = 3;
				totalC += 300;
			} else if (ones == 4) {
				INC = 4;
				totalC += 1000;
			} else if (ones == 5) {
				INC = 5;
				totalC += 2000;
			} else if (ones == 6) {
				INC = 6;
				totalC += 3000;
			}

			System.out.println("the value of INc for 1 is " + INC);
			REMOVE(0, INC, 0, 13, Array, Pane);

			System.out.println("array after removal is working");
			for (int i = 0; i < Array.size(); i++) {
				System.out.println(Array.get(i));
			}

		}

		if (ones == 1 && twos == 1 && threes == 1 && fours == 1 && fives == 1 && sixes == 1) {
			REMOVE(0, 1, 0, 13, Array, Pane);
			REMOVE(0, 1, 14, 27, Array, Pane);
			REMOVE(0, 1, 28, 41, Array, Pane);
			REMOVE(0, 1, 42, 55, Array, Pane);
			REMOVE(0, 1, 56, 69, Array, Pane);
			REMOVE(0, 1, 70, 83, Array, Pane);
			totalC += 1500;
			System.out.println("i have 1-6 straight");
		}

		return totalC;
	}

	// calculating score of farkle cards
	private int getScoreFarkle(int NoF) {
		
		if (NoF == 1) {
			totalP = 100;
			System.out.println("i have 1 Farkle");
		} else if (NoF == 2) {
			totalP = 200;
			System.out.println("i have 2 Farkles");
		} else if (NoF == 3) {
			totalP = 300;
			System.out.println("i have 3 Farkles");
		} else if (NoF == 4) {
			totalP = 1000;
			System.out.println("i have 4 Farkles");
		} else if (NoF == 5) {
			totalP = 2000;
			System.out.println("i have 5 Farkles");
		} else if (NoF == 6) {
			totalP = 3000;
			System.out.printf("i have 6 Farkles");
		}
		
		return totalP;
	}

	private void REMOVE(int c, int INC, int p1, int p2, ArrayList<Integer> Array, GridPane Pane) {
		for (int i = 0; i < Array.size(); i++) {
			c = 0;
			if (c <= INC) {
				System.out.println("Value at THIS INDEX  " + i + " " + Array.get(i));
				if (Array.get(i) >= p1 && Array.get(i) <= p2) {
					Array.remove(i);
					Pane.getChildren().remove(Pane.getChildren().get(i));
					c++;
					i = 0;
				}
			}
			if (c == INC) {
				break;
			}
		}
	}

	private String checkWinner(int currentScoreC, int currentScoreP) {
		if (currentScoreC >= 3000)
			winner = "Player1";
		else if (currentScoreP >= 3000)
			winner = "Player2";
		return winner;
	}
}